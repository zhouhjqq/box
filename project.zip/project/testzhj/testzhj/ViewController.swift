//
//  ViewController.swift
//  testzhj
//
//  Created by onlylove hl on 2021/12/14.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        //创建视图
        let redV = UIView(frame: CGRect(x: 400, y: 400, width: 300, height: 300))
                
                //设置视图的背景颜色
        redV.backgroundColor = UIColor.white;
                
                //添加到当前页面
        view.addSubview(redV);
        redV.center = view.center;
        
        let myLabel = UILabel(frame: CGRect(x: 20, y: 200, width: 150, height: 30))
                // 设置标签的内容
        myLabel.text = "请连接盒子Wi-Fi"
                // 把标签添加到主视图中
        redV.addSubview(myLabel)
        myLabel.backgroundColor = UIColor.red
//        self.view.addSubview(myLabel)
//        let uf = UITextField(frame:CGRect(x: 20, y: 30, width: 20, height: 30))
//        uf.borderStyle = UITextField.BorderStyle.none
//        redV.addSubview(uf);
//        uf.textAlignment = .left;
//        uf.placeholder = "这里是测试的"
        
                
        let btn = UIButton(type: .custom);
        redV .addSubview(btn);
        btn.backgroundColor = UIColor.blue;
        btn.setTitle("测试", for: .normal)
        btn.frame = CGRect.init(x: 50, y: 50, width: 100, height: 40)
        btn.addTarget(self, action: #selector(btnClicked), for: .touchUpInside);
                
            }

            @objc func btnClicked()->String{
                print(#function);
                print("dadsadsa");
                return "0";
              
                
    }


}




